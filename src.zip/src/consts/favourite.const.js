// Initialize Module
const FavouriteConst = {}

FavouriteConst.maxFavourite = 10

FavouriteConst.searchOptions = []
FavouriteConst.sortOptions = []
FavouriteConst.filterOptions = []

export default FavouriteConst
