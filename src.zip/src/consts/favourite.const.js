// Initialize Module
const FavouriteConst = {}

FavouriteConst.maxFavourite = 10

FavouriteConst.searchOptions = []
FavouriteConst.sortOptions = ['createdAt', 'updatedAt']
FavouriteConst.filterOptions = ['user', 'place', 'active']

export default FavouriteConst
