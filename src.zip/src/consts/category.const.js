// Initialize Module
const CategoryConst = {}

CategoryConst.searchOptions = ['name']
CategoryConst.sortOptions = ['createdAt', 'updatedAt']
CategoryConst.filterOptions = ['active']

export default CategoryConst
