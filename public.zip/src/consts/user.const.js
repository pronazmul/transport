// Initialize Module
const UserConst = {}

UserConst.searchOptions = ['name']
UserConst.sortOptions = ['followers', 'following']
UserConst.filterOptions = ['active']

export default UserConst
