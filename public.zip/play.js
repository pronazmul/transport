1. Yes please. If user hits the star on one of their saved places they categorize that as one of their “Favorit”. Each user can Favorit up to 10 (or maybe 20, I forgot the limit we set). Each time a user Favorits or Un-Favorit by selecting or deselecting the star a counter message would pop up temporarily to show how many Favorits were left.

2. The feed contains two elements:
A) posts that we will provide once we build the web-based content system (next project)

B) activity of people the user follows; that is when that followed user
- bookmarks a place
- Favorits a place
- Follows a user
- shares a place